

close all hidden
clear all
format compact

ffr_quality_stats
plots
hmm_confusion