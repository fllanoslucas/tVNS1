

clear all

load('..\data\ffrs')

for i=1:2

    ffrs0 = ffrs;

    idx = find(ffrs0.asize>900 & ffrs0.tone==i); 
    ffrs0.tone = ffrs0.tone(idx);
    ffrs0.sub = ffrs0.sub(idx);
    ffrs0.grp = ffrs0.grp(idx);
    ffrs0.src = ffrs0.src(idx);
    ffrs0.ses = ffrs0.ses(idx);

    idx1 = find(ffrs0.grp==1);  % Control = reference
    idx3 = find(ffrs0.grp==3);
    ffrs0.grp(idx1) = 3;
    ffrs0.grp(idx3) = 1;

    tab = table(nominal(ffrs0.grp),nominal(ffrs0.tone),nominal(ffrs0.ses),...
                ffrs0.sub,ffrs0.src,'VariableNames',...
                {'grp' 'tone' 'ses' 'sub' 'dv'});

    mdl = fitlme(tab,'dv~grp*ses+(1|sub)')

end
