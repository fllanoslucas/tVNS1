

clear all

%% confusion scores in ses 2

pathin = '..\hmm\results\ses2\';

flist = dir([pathin,'*.mat']);

pc = [];
grps = [];
sub = [];
ses = [];

for i=1:length(flist)
    
    load([pathin,flist(i).name])
    subid = str2double(regexp(flist(i).name,'\d*','Match'));
        
    temp = 100*length(find(reals~=preds))/length(reals);
        
    pc = [pc;temp];
    grps = [grps;grp];
    sub = [sub;subid];
    ses = [ses;2];
        
end

%% confusion scores in ses 1

pathin = '..\hmm\results\ses1\';

flist = dir([pathin,'*.mat']);

for i=1:length(flist)
    
    load([pathin,flist(i).name])
    subid = str2double(regexp(flist(i).name,'\d*','Match'));
        
    temp = 100*length(find(reals~=preds))/length(reals);
        
    pc = [pc;temp];
    grps = [grps;grp];
    sub = [sub;subid];
    ses = [ses;1];
        
end
        
%% substract confusion in ses1 from ses2

slist = intersect(sub,sub);

grp1 = [];
sub1 = [];
pc1 = [];
pc_pre = [];
pc_pos = [];

for i=1:length(slist) % sub
        
    idx2 = find(sub==slist(i) & ses==2);
    idx1 = find(sub==slist(i) & ses==1);

    pc1 = [pc1;pc(idx2)-pc(idx1)];
    sub1 = [sub1;sub(idx2)];
    grp1 = [grp1;grps(idx2)];
    
    pc_pre = [pc_pre;pc(idx1)];
    pc_pos = [pc_pos;pc(idx2)];
        
end 

%% group differences confusion changed after tVNS ?

[p tab sts] = anova1(pc1,grp1);
figure
[c,m,h,gnames] = multcompare(sts);

for i=1:3

    idx = find(grp1==i);
    [mean(pc1(idx)) std(pc1(idx))/sqrt(length(pc1(idx))) std(pc1(idx))]
    
end

%% group differences in confusion after tVNS ?

[p tab sts] = anova1(pc_pos,grp1);
figure
[c,m,h,gnames] = multcompare(sts);

  