

clear all

%%

for k=1:2

    load('..\data\ffrs')

    idx = find(ffrs.asize>=900 | ffrs.ses==k);

    ffrs.ses = ffrs.ses(idx);
    ffrs.sub = ffrs.sub(idx);
    ffrs.tone = ffrs.tone(idx);
    ffrs.grp = ffrs.grp(idx);
    ffrs.asize = ffrs.asize(idx);
    ffrs.f0 = ffrs.f0(idx,:);
    ffrs.ffr = ffrs.ffr(idx,:);
    ffrs.bsl = ffrs.bsl(idx,:);
    ffrs.src = ffrs.src(idx);

    cols = [94 60 153;230 96 8;153 216 201]/255;
    times = linspace(0,250,size(ffrs.f0,2));

    for h=1:2 

        figure   

        for i=1:3  

            idx = find(ffrs.grp==i & ffrs.tone==h);
            f0s = ffrs.f0(idx,:);
            shadeplot(times,f0s,cols(i,:),1);
            hold on;

        end

        plot(times,ffrs.tonef0(h,:),'k','linewidth',2);
        box off
        set(gca,'linewidth',2,'fontsize',25,...
        'fontname','arial','ylim',[80 150],'xlim',[0 250],...
        'xtick',[0 250],'ytick',[80 150]);
        xlabel('Time [ms]');
        ylabel('F0 [Hz]');
        title(['tone',num2str(h),' session',num2str(k)]);

    end

end

%%

load('..\data\ffrs')

listsub = intersect(ffrs.sub,ffrs.sub);

cols = [94 60 153;230 96 8;153 216 201]/255;

labels = {'tVNS-hard' 'tVNS-easy' 'Control'};

mqual = {};
mcolor = {};
msize = {};
mgroup = {};

for j=1:2 
    
    cnt = 1;

    for i=1:length(listsub)

        idx1 = find(ffrs.asize>900 & ffrs.tone==j & ffrs.sub==listsub(i) & ffrs.ses==1);
        idx2 = find(ffrs.asize>900 & ffrs.tone==j & ffrs.sub==listsub(i) & ffrs.ses==2);
        
        if isempty(idx1)==0 & isempty(idx2)==0
        
            mqual{j}(cnt,:) = [ffrs.src(idx1) ffrs.src(idx2)];
            mcolor{j}(cnt,:) = cols(ffrs.grp(idx1),:);
            msize{j}(cnt,1) = 50;
            mgroup{j}{cnt,1} = labels{ffrs.grp(idx1)};
            cnt = cnt + 1;
        
        end

    end

end

titles = {'Tone 1 (easier to categorize)' 'Tone 2 (harder to categorize)'};

for i=1:2
    
    figure;
    
    if i==1
    h=scatterhist(mqual{i}(:,1),mqual{i}(:,2),'direction','out',...
                'Group',mgroup{i},'Kernel','on',...
                'color',cols,'markersize',[8 8 8],'linewidth',[3 3 3]);
    else
    h=scatterhist(mqual{i}(:,1),mqual{i}(:,2),'direction','out',...
                'Location','SouthEast',...
                'Group',mgroup{i},'Kernel','on',...
                'color',cols,'markersize',[8 8 8],'linewidth',[3 3 3]);  
    end
    
    set(gca,'linewidth',1,'fontsize',15,'fontname','arial');
    
    x=get(gca,'children');
    v = [3 2 1];
    for k=1:3
    set(x(k),'markerfacecolor',cols(v(k),:));
    end
    
    b1 = boxplot(h(2),mqual{i}(:,1),mgroup{i},'orientation','horizontal',...
    'label',{'','',''},'color',cols);
    set(gca,'linewidth',1,'fontsize',15,'fontname','arial');
    set(b1,{'linew'},{2})
    b2 = boxplot(h(3),mqual{i}(:,2),mgroup{i},'orientation','horizontal',...
     'label', {'','',''},'color',cols);
    set(b2,{'linew'},{2})
    set(gca,'linewidth',1,'fontsize',15,'fontname','arial');

    box off
    xlabel('Pre Training');
    ylabel('Post Training');
    title(titles{i})
    
end


