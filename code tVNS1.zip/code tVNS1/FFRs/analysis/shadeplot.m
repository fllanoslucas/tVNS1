

function p = shadeplot(x,y,cols,trans)

  m = mean(y,1);
%   p=plot(x,m,'-','color',cols,'linewidth',2);
%   p.Color(4)=trans;
  
  if size(y,1)>1
  me = std(y)/sqrt(size(y,1));
  X = [x,fliplr(x)];
  Y = [m+me,fliplr(m-me)]; 
  fill(X,Y,cols,'edgealpha',0,'facealpha',0.5);
  end

end