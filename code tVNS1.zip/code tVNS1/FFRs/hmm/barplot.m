

function l=barplot(m,cols)

    cnt = 1;

    for i=1:length(m)
        
        temp = m{i};
        mn = mean(temp);
        sd = std(temp)/sqrt(length(temp));
        l(i)=bar(cnt,mn,'facecolor',cols(i,:),'linewidth',2);
        hold on;
        errorbar(cnt,mn,NaN,sd,'k','linewidth',2);
        cnt = cnt + 1;
            
    end
    
end