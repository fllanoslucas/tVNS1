

function cb = codebook(trainFold,params)

    emiTemp = [];
    
    for i=1:length(trainFold)   
       
        emiTemp = [emiTemp;trainFold{i}(:)];  
        
    end  
    
    emiTemp = intersect(emiTemp,emiTemp);

    cb = lbg(emiTemp,params.ncw);
        
end