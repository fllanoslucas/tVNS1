

function create_dataset(fpath)

    fpath = '..\processed ffrs\vns1\';

    flist = dir([fpath,'*.mat']);
    
    for i=1:length(flist)
        
        fname = flist(i).name;
        ninfo = regexp(fname,'\d*','match');
        subid(i) = str2num(ninfo{1});
        
    end

    slist = intersect(subid,subid);
    
    for i=1:length(slist)
        
        idx = find(subid==slist(i));
        
        ses0 = [];
        pol0 = [];
        ffr0 = [];
        sub0 = [];
        cls0 = [];
        snr0 = [];
        grp0 = [];
          
        for j=1:length(idx)
            
            load([fpath,flist(idx(j)).name]);
            
            ffr = resample(ffr',2000,25000);
            ffr = ffr';
            
            ses0 = [ses0;ses];
            pol0 = [pol0;pol];
            ffr0 = [ffr0;ffr];
            sub0 = [sub0;sub]; 
            cls0 = [cls0;cls];
            snr0 = [snr0;snr];
            grp0 = [grp0;grp];
           
        end
        
        ses = ses0;
        pol = pol0;
        ffr = ffr0;
        sub = sub0;
        cls = cls0;
        snr = snr0;
        grp = grp0;
        
        save(['ffrs\',num2str(slist(i)),'.mat'],'ses','pol','ffr','sub','cls','snr','grp')
        
        [i length(find(ses==2 & snr<50 & cls==1 & pol==1)) length(find(ses==2 & snr<50 & cls==1 & pol==2))...
         length(find(ses==2 & snr<50 & cls==2 & pol==2)) length(find(ses==2 & snr<50 & cls==2 & pol==2))]
        
    end

end