

function  [real pred] = evalhmm(testFold,tms,ems)

  cnt = 1;                                                              

  for h=1:length(testFold)                                                    

      m = testFold{h};                                                           

      for j=1:size(m,1)                                                   

          v = m(j,:);                                                     

          for i=1:size(tms,2)
           
             [~, logp] = hmmdecode(v,tms{i},ems{i});                            
             logps(i) = logp;  
       
          end

         [~,idx] = max(logps);                                            
         pred(cnt) = idx;                                                 
         real(cnt) = h;                                                   

         cnt = cnt + 1;                                                  

      end  
      
  end
       
end