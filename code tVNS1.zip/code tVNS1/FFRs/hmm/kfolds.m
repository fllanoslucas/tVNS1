

function [testFolds,trainFolds] = kfolds(ffrmat,labels,params)

  for i=1:max(labels)  

      idx = find(labels==i);                                  
      bf = buffer(idx,params.testsize);
      ncols = floor(length(idx)/params.testsize);
      bf = bf(:,1:ncols);

      for j=1:size(bf,2)   

          fold = ffrmat(bf(:,j),:);
          testFolds{j}{i} = movaverage(fold,params);

          idx =  setdiff([1:size(bf,2)],j);
          fold = ffrmat(bf(:,idx),:);
          trainFolds{j}{i} = movaverage(fold,params);

      end

  end
      
end
