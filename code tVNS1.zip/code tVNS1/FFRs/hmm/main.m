

close all
clear all
format compact
rng('shuffle'); 

% fpath = '..\processed ffrs\';
% create_dataset(fpath);

params.ncw = 50;  
params.totsize = 900; 
params.testsize = round(params.totsize/2); 
params.avesize = 200;  
params.sr = 2000;  
params.wl = 0.04;                                                                 
params.wo = 0.03;

% prm = randperm(params.testsize);
% save prm prm 
load prm

fpath = 'ffrs\';
flist = dir([fpath,'*.mat']);

for j=1:length(flist)
    
    tic
    length(flist) - j + 1;
    
    fname = flist(j).name;
    load([fpath,fname]);
    
    ffrmat = [];
    labels = [];
    
    for i=1:2  % tone
        
        if j==15 & i==1
            
        idx1 = find(cls==i & pol==1 & snr<50 & ses==2);
        tmp = idx1;
        idx1 = idx1(1:round(params.totsize/2));
        idx1 = idx1(prm); 
        idx2 = find(cls==i & pol==2 & snr<50 & ses==2);
        idx2 = [idx2;tmp(1+round(params.totsize/2))];
        idx2 = idx2(prm); 
        idx2 = idx2(1:round(params.totsize/2));
        idx = [idx1;idx2];
        idx = idx(:);
        ffrmat = [ffrmat;ffr(idx,:)];
        labels = [labels;cls(idx)];
            
        else
        
        idx1 = find(cls==i & pol==1 & snr<50 & ses==2);
        idx1 = idx1(1:round(params.totsize/2));
        idx1 = idx1(prm); 
        idx2 = find(cls==i & pol==2 & snr<50 & ses==2);
        idx2 = idx2(prm); 
        idx2 = idx2(1:round(params.totsize/2));
        idx = [idx1;idx2];
        idx = idx(:);
        ffrmat = [ffrmat;ffr(idx,:)];
        labels = [labels;cls(idx)];
        
        end
        
    end
    
    [reals preds] = runhmm(ffrmat,labels,params);
        
    grp = grp(1);
    
    save(['results\',fname(1:4),'.mat'],'reals','preds','grp');
    
    cm = confusionmat(reals,preds);
    cm = cm./sum(cm(1,:),2)
    figure;
    imagesc(cm)
    axis off
    title(fname(1:4));
    saveas(gcf,['figures\',fname(1:4),'.tiff'])
     
    ela = toc;
    
    ela/60

end




