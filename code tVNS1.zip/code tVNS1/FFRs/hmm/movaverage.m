

function nfold = movaverage(fold,params)

    wl = params.avesize;
                                                            
    if mod(wl,2)==0 
        
       pre = wl/2;
       pos = wl/2 - 1;
    
    else
        
       pre = (wl-1)/2;
       pos = pre;
    
    end
                                                       
    for j=1:size(fold,1)  
        
        idx = mod([j-pre:j+pos],size(fold,1));
        idx(find(idx==0)) = size(fold,1);
        aveffr = mean(fold(idx,:),1); 
        nfold(j,:) = f0track(aveffr,params.sr,[100 200]);
       
    end
              
end
        