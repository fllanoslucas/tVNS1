

function emisFold = quantization(trainFold,cb)

    for i=1:length(trainFold) 
        
      emis = [];
            
      for j=1:size(trainFold{i},1) 
          
          f0s = trainFold{i}(j,:);
          emi = [];
          
          for k=1:length(f0s)
              
              d = pdist2(f0s(k),cb);                                                      
              [~,idx] = min(d);
              emi(1,k) = idx; 
     
          end
         
          emis(j,:) = emi;
          
      end  
        
      emisFold{i} = emis;
                                                                            
    end
    
end

