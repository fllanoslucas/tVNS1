

function [reals preds] = runhmm(ffrmat,labels,params)

    [testFolds,trainFolds] = kfolds(ffrmat,labels,params);
    
    reals = [];
    preds = [];

    for j=1:length(testFolds)
        
        trainFold = trainFolds{j};
        testFold = testFolds{j};

        cb = codebook(trainFold,params);

        trainFold = quantization(trainFold,cb); 
        [tms ems] = trainhmm(trainFold,cb,params);                                  

        testFold = quantization(testFold,cb);   
        [real pred] = evalhmm(testFold,tms,ems);

        reals = [reals;real'];
        preds = [preds;pred'];
        
    end

end
