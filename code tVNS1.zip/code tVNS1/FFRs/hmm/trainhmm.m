

function [tms ems] = trainhmm(trainFold,cb,params)

    for j=1:length(trainFold)                                               
                
       emis = trainFold{j};                                                    
       [tm_ini,em_ini] = initmats(3,emis,size(cb,1));   
       [tms{j} ems{j}] = hmmtrain(emis,tm_ini,em_ini,...                                       
                         'algorithm','Viterbi',...
                         'Pseudoemissions',0.001*ones(size(em_ini)),...
                         'Pseudotransitions',0.001*ones(size(tm_ini))); 
    end
      
end