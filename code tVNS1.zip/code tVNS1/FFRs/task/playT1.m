
close all
clear all

t1 = audioread('t1_1.wav');
t1 = resample(t1,25000,44100);

params.stim = t1;
params.fs = 25000;
params.jitter = 0.02;
params.reps = 1100;
params.isi = 0.125;

jitters = params.jitter*rand([1 params.reps]);                          

for i=1:length(jitters)                                                 
isi{i} = zeros(round((params.isi+jitters(i))*params.fs),1);
end

pol1 = params.stim;                                                   
pol2 = -1*params.stim;                                                         

epoch = [isi{1}];                                                           
cnt = 1;
for i=1:params.reps/2
    epoch = [epoch;pol1;isi{cnt}]; 
    cnt = cnt + 1;
    epoch = [epoch;pol2;isi{cnt}]; 
    cnt = cnt + 1;
end

player = audioplayer(epoch,params.fs);                               
play(player);








