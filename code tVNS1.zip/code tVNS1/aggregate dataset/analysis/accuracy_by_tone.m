

clear all

load('..\data\aggregate')

idx = find(aggregate.exp>20 | aggregate.exp==11); % exclude musicians (11) and tVNS & Control conditions (21-24)
aggregate.sub(idx) = [];
aggregate.block(idx) = [];
aggregate.tone(idx) = [];
aggregate.resp(idx) = [];
aggregate.trial(idx) = [];
aggregate.gen(idx) = []; % generalization block?

range = [1 85];
aggregate = trimset(aggregate,range);

listsub = intersect(aggregate.sub,aggregate.sub);

pc = [];
tone = [];

for i=1:length(listsub)
    
    for j=1:4
    
        hit = length(find(aggregate.sub==listsub(i) & aggregate.tone==j & aggregate.resp==j));
        tot = length(find(aggregate.sub==listsub(i) & aggregate.tone==j));
        pc = [pc;hit/tot];
        tone = [tone;j];
    
    end
    
end

[a b c] = anova1(pc,tone,'display','off');
multcompare(c,'alpha',0.0125)

