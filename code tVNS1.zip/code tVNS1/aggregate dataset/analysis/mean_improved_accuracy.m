

function mia = mean_improved_accuracy(aggregate)
    
    listsub = intersect(aggregate.sub,aggregate.sub);
                   
    for i=1:length(listsub)
        
        lc = [];
        
        idx = find(aggregate.sub==listsub(i) & aggregate.gen==0);
        ntrials = max(aggregate.trial(idx));
        vec = [1:40:ntrials-39];   
        cut = min(length(vec),6); % include only 6 blocks
        
        for j=1:cut
            
            idx = find(aggregate.sub==listsub(i) & aggregate.gen==0 & aggregate.trial>=vec(j) & aggregate.trial<=vec(j)+40-1);
            temp = 100*length(find(aggregate.resp(idx)==aggregate.tone(idx)))/length(idx);
            lc(j) = temp;
                    
        end
        
        lc = lc-lc(1); % accuracy improved over Block 1
        lc(1) = [];
        mia{i,1} = mean(lc); % mean improved accuracy
               
    end
    
end
        