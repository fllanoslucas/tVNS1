

clear all

%% aggregated dataset

load('..\data\aggregate')

idx = find(aggregate.exp>20 | aggregate.exp==11); % exclude musicians (11) and tVNS & Control conditions (21-24)
aggregate.sub(idx) = [];
aggregate.block(idx) = [];
aggregate.tone(idx) = [];
aggregate.resp(idx) = [];
aggregate.trial(idx) = [];
aggregate.gen(idx) = []; % generalization block?

%% remove outliers (Block 1  performance)

range = [1 85];
aggregate = trimset(aggregate,range);

%% mean improved accuracies

mias_agr =  mean_improved_accuracy(aggregate);
mean(cat(1,mias_agr {:}))

cnt = 1;

for j=[21 22 23] % tVNS and Control conditions
   
    load('..\data\aggregate')

    idx = find(aggregate.exp~=j);
    aggregate.sub(idx) = [];
    aggregate.block(idx) = [];
    aggregate.tone(idx) = [];
    aggregate.resp(idx) = [];
    aggregate.gen(idx) = [];
    aggregate.trial(idx) = [];
    aggregate.exp(idx) = [];
    
    tmp = mean_improved_accuracy(aggregate);
    mias_tvns(cnt) = sum(nanmean(cat(1,tmp{:})));
    
    cnt = cnt + 1;
    
end

%% permutations
    
perms = [];

nperm = 1000;

rng(1)

for i=1:nperm

    idx = randperm(numel(mias_agr));
    idx = idx(1:12);
    perms(i) = nanmean(cat(1,mias_agr{idx}));

end

for i=1:3
    
    ps(i) = 1-length(find(perms<mias_tvns(i)))/nperm;
    
end

ps
    


