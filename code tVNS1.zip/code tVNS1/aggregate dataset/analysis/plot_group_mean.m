

function p = plot_group_mean(aggregate,trans,col,sig,semsig,dsz)
    
    listsub = intersect(aggregate.sub,aggregate.sub);
    
    idx = find(aggregate.gen==0);
    nblocks = max(aggregate.block(idx));
        
    listone = intersect(aggregate.tone,aggregate.tone);
    
    pc = [];
    trl = [];
    
    for i=1:length(listsub)
                
        idx = find(aggregate.sub==listsub(i) & aggregate.gen==0);
        ntrials = max(aggregate.trial(idx));
        
        vec = [1:40:ntrials-39];
        
        for j=1:length(vec)
                       
            for k=1:length(listone)
                        
                idx = find(aggregate.sub==listsub(i)...
                          & aggregate.gen==0 ...
                          & aggregate.tone==listone(k) ...
                          & aggregate.trial>=vec(j) ...
                          & aggregate.trial<=vec(j)+40-1);
                      
                temp = 100*length(find(aggregate.resp(idx)== ...
                       aggregate.tone(idx)))/length(idx);
                   
                pc = [pc;temp];
                trl = [trl;j];
            
            end
        
        end
                
    end
        
    m = [];
    
    ntrials = min(ntrials,6);
    
    for i=1:ntrials
        
        idx = find(trl==i);
                
        m(i) = nanmean(pc(idx));
        sem(i) = nanstd(pc(idx))/sqrt(length(idx));
                
        l = scatter(i,m(i),dsz,'bo','MarkerFaceColor',col,'MarkerEdgeColor',col);
        l.MarkerFaceAlpha = trans;
        l.MarkerEdgeAlpha = trans;
        hold on;
        
        if isnan(sig)==0
            
            pd = fitdist(pc(idx),'Normal');
            ci = paramci(pd,'Alpha',sig);
            ci = ci(:,1);
             
            p = plot([i i],[ci(1) ci(2)],'-','color',col,'linewidth',2);
            
        else
            
            p = plot([i i],[m(i)-semsig*sem(i) m(i)+semsig*sem(i)],'-','color',col,'linewidth',3);
            
        end
        
        p.Color(4) = trans;        
    
    end
    
    
    p = plot([1:ntrials],m,'-','color',col,'linewidth',4);
    p.Color(4) = trans;
    
end
