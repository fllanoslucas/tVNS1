
function p = plot_individual_variability(aggregate,col,trans)
    
    listsub = intersect(aggregate.sub,aggregate.sub);
    
    idx = find(aggregate.gen==0);
    nblocks = max(aggregate.block(idx));
        
    listone = intersect(aggregate.tone,aggregate.tone);
    
    pc = [];
    trl = [];
    subid = [];
    
    for i=1:length(listsub)
                
        idx = find(aggregate.sub==listsub(i) & aggregate.gen==0);
        ntrials = max(aggregate.trial(idx));
        
        vec = [1:40:ntrials-39];
        
        for j=1:length(vec)
                       
            for k=1:length(listone)
                        
                idx = find(aggregate.sub==listsub(i) ...
                           & aggregate.gen==0 ...
                           & aggregate.tone==listone(k) ...
                           & aggregate.trial>=vec(j) ...
                           & aggregate.trial<=vec(j)+40-1);
                      
                temp = 100*length(find(aggregate.resp(idx)==...
                       aggregate.tone(idx)))/length(idx);
                
                pc = [pc;temp];
                trl = [trl;j];
                subid = [subid;listsub(i)];
            
            end
        
        end
                
    end
            
    for k=1:length(listsub)
        
         m = [];

        for i=1:ntrials

            idx = find(trl==i & subid==listsub(k));
            m(i) = nanmean(pc(idx));
            sem(i) = nanstd(pc(idx))/sqrt(length(idx));
      
        end

        p = plot([1:ntrials],m,'-','color',col,'linewidth',2);
        p.Color(4) = trans;
        hold on
    
    end
    
end



