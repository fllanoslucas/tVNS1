

clear all

%% aggregate - individual lerning curves

load('..\data\aggregate')
idx = find(aggregate.exp>20 | aggregate.exp==11); % exclude musicians (11) and tVNS & Control conditions (21-24)
aggregate.sub(idx) = [];
aggregate.block(idx) = [];
aggregate.tone(idx) = [];
aggregate.resp(idx) = [];
aggregate.trial(idx) = [];
aggregate.gen(idx) = []; % generalization block?

range = [1 85];
aggregate = trimset(aggregate,range);

figure;
plot_individual_variability(aggregate,[0 0 1],0.1);
plot_group_mean(aggregate,1,[0 0 0],NaN,0,100);
box off
set(gca,'xtick',[1:6],'ylim',[0 100],'fontsize',20,'ytick',[0 50 100],...
'fontweight','bold','xlim',[.8 6],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out')

%%  aggregate - tone learning curves by contrast

clear all
format compact

legends = {'Tones 1 and 3' 'Tones 2 and 4'};
cols = [230 97 1;94 60 153]/255;

figure;

l = [];

cont = [1 3;2 4];

for i=1:2

    load('..\data\aggregate')
    idx = find(aggregate.exp == 11 | aggregate.exp > 20 ...
          | (aggregate.tone ~= cont(i,1) & aggregate.tone ~= cont(i,2))); 
          
    aggregate.sub(idx) = [];
    aggregate.block(idx) = [];
    aggregate.tone(idx) = [];
    aggregate.resp(idx) = [];
    aggregate.gen(idx) = [];
    aggregate.trial(idx) = [];

    range = [1 85];
    aggregate = trimset(aggregate,range);
    
    l(i) = plot_group_mean(aggregate,1,cols(i,:),0.01,1,100);

end

box off
set(gca,'xtick',[1:6],'ylim',[25 65],'fontsize',18,...
'fontweight','bold','xlim',[.9 6],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out')
xlabel('Block','fontsize',20,'fontweight','bold')
ylabel('Percent Correct','fontsize',20,'fontweight','bold');

legend(l,legends,'location','southeast','fontsize',20);
legend boxoff

%% aggregate and tVNS learning curves

clear all

figure

l = [0 0 0 0];

cols = [94 60 153;230 96 8;153 216 201]/255;
trans = [1 1 1];

legends = {'Aggregate' 'tVNS-hard' 'tVNS-easy' 'Control'};

cnt = 2;

for i=[21 22 23]
    
    load('..\data\aggregate')       

    idx = find(aggregate.exp~=i);
    aggregate.sub(idx) = [];
    aggregate.block(idx) = [];
    aggregate.tone(idx) = [];
    aggregate.resp(idx) = [];
    aggregate.trial(idx) = [];
    aggregate.gen(idx) = []; 
  
    l(cnt) = plot_group_mean(aggregate,1,cols(cnt-1,:),NaN,1,100);
    
    cnt = cnt + 1;
        
end

load('..\data\aggregate')  

idx = find(aggregate.exp>20 | aggregate.exp==11);
aggregate.sub(idx) = [];
aggregate.block(idx) = [];
aggregate.tone(idx) = [];
aggregate.resp(idx) = [];
aggregate.trial(idx) = [];
aggregate.gen(idx) = []; 

range = [1 85];
aggregate = trimset(aggregate,range);

l(1) = plot_group_mean(aggregate,1,[0 0 0],0.001,0,100);

box off
set(gca,'xtick',[1:6],'ylim',[25 75],'fontsize',18,'ytick',[25 50 75],...
'fontweight','bold','xlim',[.8 6],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out')
xlabel('Block','fontsize',20,'fontweight','bold')
ylabel('Percent Correct','fontsize',20,'fontweight','bold');

legend(l,legends,'location','southeast','fontsize',20);
legend boxoff

