

function aggregate0 = trimset(aggregate,range)

    idx = find(aggregate.gen==0); % exclude generalization block (not all subs have it)
    nblocks = max(aggregate.block(idx));
            
    pc = [];
    subid = [];
    
    listsub = intersect(aggregate.sub,aggregate.sub);
    
    for i=1:length(listsub)
                
        idx = find(aggregate.sub==listsub(i) & aggregate.gen==0);
        ntrials = max(aggregate.trial(idx));
        vec = [1:40:ntrials-39];
                               
        idx = find(aggregate.sub==listsub(i) & ...
                   aggregate.gen==0 & ...
                   aggregate.trial>=vec(1) & ...
                   aggregate.trial<=vec(1)+40-1);
               
        tmp = 100*length(find(aggregate.resp(idx)==aggregate.tone(idx)))/length(idx);
        
        pc = [pc;tmp];
        subid = [subid;listsub(i)];
            
    end
    
    % remove subs out of range for accuracy in block 1
        
    tmp = subid(find(pc>range(2) | pc<range(1)));
    listreject = intersect(tmp,tmp);
    idx = find(ismember(aggregate.sub,listreject)==1);
    
    aggregate0 = aggregate; 
    
    aggregate0.sub(idx) = [];
    aggregate0.block(idx) = [];
    aggregate0.tone(idx) = [];
    aggregate0.resp(idx) = [];
    aggregate0.gen(idx) = [];
    aggregate0.trial(idx) = [];
    aggregate0.exp(idx) = [];
    
end