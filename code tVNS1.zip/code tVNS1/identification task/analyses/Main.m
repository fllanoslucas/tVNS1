

close all hidden
clear all
format compact

logit_stats
plot_stim_f0s



