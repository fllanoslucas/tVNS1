

clear all

%% logit

pathins = {'..\data\tVNS-hard\'...
           '..\data\tVNS-easy\'...
           '..\data\Control\'};

beta = [];
subid = [];
grp = [];

for i=1:numel(pathins)
    
    pathin = pathins{i};
    
    tmp = logitmodel(pathin);
    
    grp = [grp;i*ones(size(tmp.subid))];
    beta = [beta;tmp.beta];
    subid = [subid;tmp.subid]; 
    
end

%% anova

anova1(beta,grp)
