

function logvars = logitmodel(pathin)
     
     logvars.beta = []; 
     logvars.subid = []; 
     
     filelist = dir([pathin,'*.xlsx']);
     
     for i=1:length(filelist) 
         
         filename = filelist(i).name;
         tab = xlsread([pathin,filename]);
         
         info =  regexp(filename,'[0-9]*','match');
         logvars.subid = [logvars.subid;str2num(info{1})];
         
         resp = tab(:,33); 
         step = tab(:,24);
         
         idx = find(resp==3); % conver 3s to 0s (binary logit) 
         resp(idx) = 0;   
         b = glmfit(step,resp,'binomial','link','logit');
         
         if b(2) < 0 % correct if some subjects switched buttons
           
             idx0 = find(resp==0);
             idx1 = find(resp==1);
             resp(idx0) = 1;
             resp(idx1) = 0;             
             b = glmfit(step,resp,'binomial','link','logit');
             
         end
         
         logvars.beta = [logvars.beta;b(2)];
         
         % plot
 
%          odd = [];
%          
%          for j=1:max(step)
%              
%             odd(j) = length(find(step==j & resp==1))/length(find(step==j));
%          
%          end
%          
%          figure;
%          plot(odd,'r--','linewidth',2);
%          hold on;
%          range = [1:.1:7];
%          yhat = glmval(b,range,'logit');       
%          plot(range,yhat,'linewidth',2);hold on;
%          box off;
%          title(['Subject: ',info{1}]);
%          xlabel('Steps');
%          ylabel('Proportion of "rising"');
%          set(gca,'linewidth',2,'fontsize',15);
%          legend('Raw','Logit','location','northwest');
%          ylim([0 1])
                      
     end

end