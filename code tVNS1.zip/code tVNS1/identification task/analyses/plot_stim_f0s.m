

clear all

files = dir('../stimuli/*.wav');

colend = [230 97 1;178 171 210]/255;
a1 = linspace(colend(1,1),colend(2,1),7)';
a2 = linspace(colend(1,2),colend(2,2),7)';
a3 = linspace(colend(1,3),colend(2,3),7)';
tcolors = [a1 a2 a3];
trans = [1 1 1 1 1 1 1]

figure;
    
for i=1:length(files)
    
    [s sr] = audioread(['../stimuli/',files(i).name]);
    s(1:sr*0.04)=[];
    f0 = f0track(s,sr,[90 400]);
    t = (1000/sr)*linspace(0,length(s),length(f0));
    p(i)=plot(t,f0,'-','color',[tcolors(i,:) trans(i)],'linewidth',2);
    hold on;
    
end

yyaxis right
set(gca,'linewidth',2,'fontsize',18,'fontname','arial','fontweight','bold',...
'ytick',[0 .5 1],'yticklabels',{'100' '120' '140'});
ylabel('F0 [Hz]')
yyaxis left
box off
set(gca,'linewidth',2,'fontsize',18,'fontname','arial','fontweight','bold',...
'ylim',[100 135],'xlim',[t(1) t(end)],'xtick',[t(1) floor(t(round(end/2))) t(end)],...
'ytick',[linspace(107,130,7)],...
'yticklabels',{'7=Rising' '6' '5' '4' '3' '2' '1=Level'});
xlabel('Time [ms]','fontsize',20);
set(gca,'TickDir','out')

