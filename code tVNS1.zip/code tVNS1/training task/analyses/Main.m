

close all hidden
clear all
format compact

accuracy_stats
plots
plot_moving_window
retention_correct_trials