

clear all

%% input glme(s)

vars.trial = [];
vars.hit = [];
vars.sub = [];
vars.grp = [];
vars.tone = [];
vars.block = [];

pathins = {'..\data\tVNS-hard\',...
           '..\data\tVNS-easy\',...
           '..\data\Control\',...
           '..\data\tVNS-feedback\'};
           
for i=1:length(pathins)

    pathin = pathins{i};
    
    tmp = input_glme(pathin);

    vars.hit = [vars.hit;tmp.hit];
    vars.sub = [vars.sub;tmp.sub];
    vars.grp = [vars.grp;i*ones(size(tmp.sub))];
    vars.trial = [vars.trial;tmp.trial];
    vars.tone = [vars.tone;tmp.tone];
    vars.block = [vars.block;tmp.block];
    
end

%% glme - training - all tones

vars0 = vars;

idx = find(vars0.block==7 | vars0.grp==4); 
vars0.hit(idx) = [];
vars0.sub(idx) = [];
vars0.grp(idx) = [];
vars0.trial(idx) = [];
vars0.tone(idx) = [];

idx1 = find(vars0.grp==1); % relevel group (reference = control group)
idx3 = find(vars0.grp==3);
vars0.grp(idx3) = 1;
vars0.grp(idx1) = 3;

idx1 = find(vars0.tone==1); % relevel tone (reference = tone4)
idx4 = find(vars0.tone==4);
vars0.tones(idx4) = 1;
vars0.tones(idx1) = 4;

T = table(vars0.sub,vars0.trial,nominal(vars0.grp),...
            nominal(vars0.tone),vars0.hit,...
           'VariableNames',{'subject','trial','group','tone','hit'});
        
mdl = fitglme(T,'hit ~ group*trial + (1|subject) + (1|tone)',...
              'Distribution','Binomial','Link','logit')
          
% mdl = fitglme(T,'hit ~ group*trial + (1|subject) + (group|tone)',...
%   'Distribution','Binomial','Link','logit') % model with random slope -> worse deviance
           

%% glme - training - easier to learn tones

vars0 = vars;

idx = find((vars0.tone~=1 & vars0.tone~=3) | vars0.block==7 | vars0.grp==4); 
vars0.hit(idx) = [];
vars0.sub(idx) = [];
vars0.grp(idx) = [];
vars0.trial(idx) = [];
vars0.tone(idx) = [];

idx1 = find(vars0.grp==1); % relevel group (reference = control group)
idx3 = find(vars0.grp==3);
vars0.grp(idx3) = 1;
vars0.grp(idx1) = 3;

idx1 = find(vars0.tone==1); % relevel tone (reference = tone4)
idx4 = find(vars0.tone==4);
vars0.tones(idx4) = 1;
vars0.tones(idx1) = 4;

T = table(vars0.sub,vars0.trial,nominal(vars0.grp),...
            nominal(vars0.tone),vars0.hit,...
           'VariableNames',{'subject','trial','group','tone','hit'});
        
mdl = fitglme(T,'hit ~ group*trial + (1|subject) + (1|tone)',...
              'Distribution','Binomial','Link','logit')

%% glme - training - harder to learn tones

vars0 = vars;

idx = find((vars0.tone~=2 & vars0.tone~=4) | vars0.block==7 | vars0.grp==4); 
vars0.hit(idx) = [];
vars0.sub(idx) = [];
vars0.grp(idx) = [];
vars0.trial(idx) = [];
vars0.tone(idx) = [];

idx1 = find(vars0.grp==1); % relevel group (reference = control group)
idx3 = find(vars0.grp==3);
vars0.grp(idx3) = 1;
vars0.grp(idx1) = 3;

idx1 = find(vars0.tone==1); % relevel tone (reference = tone4)
idx4 = find(vars0.tone==4);
vars0.tones(idx4) = 1;
vars0.tones(idx1) = 4;

T = table(vars0.sub,vars0.trial,nominal(vars0.grp),...
            nominal(vars0.tone),vars0.hit,...
           'VariableNames',{'subject','trial','group','tone','hit'});
        
mdl = fitglme(T,'hit ~ group*trial + (1|subject) + (1|tone)',...
              'Distribution','Binomial','Link','logit')
          
%% glme - generalization

vars0 = vars;

idx = find(vars0.block~=1 & vars0.block~=7 | vars0.grp==4); 
vars0.hit(idx) = [];
vars0.sub(idx) = [];
vars0.grp(idx) = [];
vars0.trial(idx) = [];
vars0.tone(idx) = [];
vars0.block(idx) = [];

idx1 = find(vars0.grp==1); % relevel group (reference = control group)
idx3 = find(vars0.grp==3);
vars0.grp(idx3) = 1;
vars0.grp(idx1) = 3;

idx1 = find(vars0.tone==1); % relevel tone (reference = tone4)
idx4 = find(vars0.tone==4);
vars0.tones(idx4) = 1;
vars0.tones(idx1) = 4;

T = table(vars0.sub,vars0.trial,nominal(vars0.grp),...
          nominal(vars0.tone),vars0.hit,vars0.block,...
          'VariableNames',{'subject','trial','group',...
          'tone','hit','block'});
        
mdl = fitglme(T,'hit ~ group*block + (1|subject) + (1|tone)',...
              'Distribution','Binomial','Link','logit')
          
%% glme - training - all tones - by block instead of by trial (just for Figure 2)

vars0 = vars;

idx = find(vars0.block==7 | vars0.grp==4); 
vars0.hit(idx) = [];
vars0.sub(idx) = [];
vars0.grp(idx) = [];
vars0.trial(idx) = [];
vars0.tone(idx) = [];
vars0.block(idx) = [];

idx1 = find(vars0.grp==1); % relevel group (reference = control group)
idx3 = find(vars0.grp==3);
vars0.grp(idx3) = 1;
vars0.grp(idx1) = 3;

idx1 = find(vars0.tone==1); % relevel tone (reference = tone4)
idx4 = find(vars0.tone==4);
vars0.tones(idx4) = 1;
vars0.tones(idx1) = 4;

T = table(vars0.sub,vars0.trial,nominal(vars0.grp),...
            nominal(vars0.tone),vars0.hit,ordinal(vars0.block),...
           'VariableNames',{'subject','trial','group','tone','hit','block'});
        
mdl = fitglme(T,'hit ~ group*block + (1|subject) + (1|tone)',...
              'Distribution','Binomial','Link','logit');
          
%% glme - tVNS-feedback vs. Control vs. tVNS-easy

vars0 = vars;

idx = find(vars0.grp==1 | vars0.trial>120); 
vars0.hit(idx) = [];
vars0.sub(idx) = [];
vars0.grp(idx) = [];
vars0.trial(idx) = [];
vars0.tone(idx) = [];
vars0.block(idx) = [];

idx3 = find(vars0.grp==3); % relevel group (reference = control group)
idx2 = find(vars0.grp==2);
idx4 = find(vars0.grp==4);
vars0.grp(idx3) = 1;
vars0.grp(idx2) = 2;
vars0.grp(idx4) = 3;

idx1 = find(vars0.tone==1); % relevel tone (reference = tone4)
idx4 = find(vars0.tone==4);
vars0.tones(idx4) = 1;
vars0.tones(idx1) = 4;

T = table(vars0.sub,vars0.trial,nominal(vars0.grp),...
            nominal(vars0.tone),vars0.hit,ordinal(vars0.block),...
           'VariableNames',{'subject','trial','group','tone','hit','block'});
        
mdl = fitglme(T,'hit ~ group*trial + (1|subject) + (1|tone)',...
              'Distribution','Binomial','Link','logit')
