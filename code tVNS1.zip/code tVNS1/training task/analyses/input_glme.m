

function  vars = byTrial_input_glme(pathin)

    vars.hit = [];
    vars.sub = [];
    vars.grp = [];
    vars.block = [];
    vars.tone = [];
    vars.trial = [];
    
    flist = dir([pathin,'*.mat']);

    for i=1:length(flist)

        fname = flist(i).name;
        iname = regexp(fname,'_','split');
        sub = str2num(iname{2}(4:7));

        load([pathin,fname]);

        block = cell2mat(data(:,1));
        resp = cell2mat(data(:,7));
        tone = cell2mat(data(:,6));
                
        hit = zeros(size(resp));
        idx = find(resp==tone);
        hit(idx) = 1;
        
        vars.hit = [vars.hit;hit];
        vars.sub = [vars.sub;sub*ones(size(hit))];
        vars.block = [vars.block;block];
        vars.tone = [vars.tone;tone];
        vars.trial = [vars.trial;[1:length(hit)]'];
        
    end
                   
end

