

function  vars = input_plot_moving_window(pathin)

    vars.pc = [];
    vars.sub = [];
    vars.trial = [];
    
    flist = dir([pathin,'*.mat']);

    for i=1:length(flist)

        fileName = flist(i).name;
        iname = regexp(fileName,'_','split');
        subid = str2num(iname{2}(4:7));

        load([pathin,fileName]);

        block = cell2mat(data(:,1));
        resp = cell2mat(data(:,7));
        cat = cell2mat(data(:,6));
        
        block = block([1:120]); % 120 = tVNS-feedback trials
        resp = resp([1:120]);
        cat = cat([1:120]);
        
        hits = zeros(size(resp));
        idx = find(resp==cat);
        hits(idx) = 1;
        
        for j=1:120
            
            tmp = [j-20+1:j+20];
            idx = find(tmp<1 | tmp>120);
            tmp(idx) = [];
            
            vars.pc = [vars.pc;100*mean(hits(tmp))]; 
            vars.trial = [vars.trial;j];
            vars.sub = [vars.sub;subid];
            
        end
        
    end
       
end