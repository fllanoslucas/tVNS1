

function  vars = input_plots(pathin)

    vars.sub = [];
    vars.block = [];
    vars.tone = [];
    vars.fp = [];
    vars.pc = [];
    
    flist = dir([pathin,'*.mat']);

    for i=1:length(flist)

        fileName = flist(i).name;
        iname = regexp(fileName,'_','split');
        sub = str2num(iname{2}(4:7));

        load([pathin,fileName]);

        block = cell2mat(data(:,1));
        resp = cell2mat(data(:,7));
        tone = cell2mat(data(:,6));

        for j=1:7  
            
            for k=1:4                 
                
                idx1 = find(block==j);
                
                if isempty(idx1)==0
                    
                     idx = find(block==j & resp==tone & tone==k);
                     pc = 100*length(idx)/length(find(block==j & tone==k));
                     
                     idx = find(block==j & resp==k & tone~=k);
                     fp = 100*length(idx)/length(find(block==j & tone~=k));
                     
                else
                    
                     pc = NaN;
                     fp = NaN;

                end
                
                vars.sub = [vars.sub;sub];
                vars.block = [vars.block;j];
                vars.tone = [vars.tone;k]; 
                vars.fp = [vars.fp;fp];
                vars.pc = [vars.pc;pc];

            end
            
        end

    end

end

