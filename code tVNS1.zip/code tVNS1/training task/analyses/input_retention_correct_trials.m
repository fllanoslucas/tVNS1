

function vars = input_retention_correct_trials(pathin)

    vars.sub = [];
    vars.block = [];
    vars.pr = [];
    
    flist = dir([pathin,'*.mat']);

    for i=1:length(flist)

        fname = flist(i).name;

        infoName = regexp(fname,'_','split');
        sub = str2num(infoName{2}(4:7));

        load([pathin,fname]);

        block = cell2mat(data(:,1));
        resp = cell2mat(data(:,7));
        cat = cell2mat(data(:,6));

        for j=1:5 
                                 
            idx = find(block==j & resp==cat);          
            pre = str_to_number(data(idx,3));

            idx = find(block==j+1 & resp==cat);            
            cur = str_to_number(data(idx,3));
            
            if isempty(idx)==0
            
                vars.pr = [vars.pr;length(intersect(pre,cur))]; 
                vars.sub = [vars.sub;sub];
                vars.block = [vars.block;j+1]; 
            
            else
                
                vars.pr = NaN; 
                vars.sub = NaN;
                vars.block = NaN; 
                
            end
                        
        end

    end

end

