

clear all
format compact

%% input plots

vars.trial = [];
vars.pc = [];
vars.sub = [];
vars.grp = [];

pathins = {'..\data\tVNS-easy\',...
           '..\data\tVNS-feedback\',...
           '..\data\Control\'};
     
for i=1:length(pathins)

    tmp = input_plot_moving_window(pathins{i});
    
    vars.sub = [vars.sub;tmp.sub];
    vars.pc = [vars.pc;tmp.pc];
    vars.grp = [vars.grp;i*ones(size(tmp.sub))];
    vars.trial = [vars.trial;tmp.trial];

end

%% plot learning curves 

cols = [230 96 8;94 60 153;153 216 201]/255;
trans = [1 1 1];
figure;

for j=1:3 
    
    for k=1:max(vars.trial)
        
        idx = find(vars.trial==k & vars.grp==j);
        x(k) = nanmean(vars.pc(idx));
        sem = nanstd(vars.pc(idx))/sqrt(length(idx));
        l(j) = scatter(k,x(k),40,'bo','MarkerFaceColor',cols(j,:),'MarkerEdgeColor',cols(j,:));
        l(j).MarkerFaceAlpha = trans(j);
        l(j).MarkerEdgeAlpha = trans(j);
        hold on;
        p = plot([k k],[x(k)-sem x(k)+sem],'-','color',cols(j,:),'linewidth',2);
        p.Color(4) = 0.3;
        
    end
    
    p = plot([1:6],x(1:6),'-','color',cols(j,:),'linewidth',3);
    p.Color(4) = trans(j);

end

box off
set(gca,'xtick',[1 60 120],'ylim',[20 75],'fontsize',20,'ytick',[25 50 75],...
'fontweight','bold','xlim',[0 121],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out','xticklabels',{'1' '60' '120'})
xlabel('Trial','fontsize',20,'fontweight','bold')
ylabel('Percent Correct','fontsize',20,'fontweight','bold');
legend(l,{'tVNS easy' 'tVNS feedback'  'Control'},'location','northwest','linewidth',2,'fontsize',15);
legend boxoff 
