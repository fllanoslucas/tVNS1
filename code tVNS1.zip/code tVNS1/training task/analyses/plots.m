

clear all
format compact

%% input plots

vars.fp = [];
vars.pc = [];
vars.sub = [];
vars.grp = [];
vars.tone = [];
vars.block = [];

pathins = {'..\data\tVNS-hard\',...
           '..\data\tVNS-easy\',...
           '..\data\Control\'};
     
for i=1:length(pathins)

    tmp = input_plots(pathins{i});
    
    vars.sub = [vars.sub;tmp.sub];
    vars.pc = [vars.pc;tmp.pc];
    vars.grp = [vars.grp;i*ones(size(tmp.fp))];
    vars.block = [vars.block;tmp.block];
    vars.tone = [vars.tone;tmp.tone];
    vars.fp = [vars.fp;tmp.fp];

end

%% false positives

cols = [94 60 153;230 96 8;153 216 201]/255;
trans = [1 1 1 1];

figure;

cnt = 1;

for j=1:3 
        
    x = [];

    for k=1:7 
        
        idx = find(vars.block==k & (vars.tone==1 | vars.tone==3) & vars.grp==j);
        
        x(k) = nanmean(vars.fp(idx));
        sem = nanstd(vars.fp(idx))/sqrt(length(idx));
        
        l(cnt) = scatter(k,x(k),40,'bo','MarkerFaceColor',cols(cnt,:),'MarkerEdgeColor',cols(cnt,:));
        l(cnt).MarkerFaceAlpha = trans(cnt);
        l(cnt).MarkerEdgeAlpha = trans(cnt);
        
        hold on;
        p = plot([k k],[x(k)-sem x(k)+sem],'-','color',cols(cnt,:),'linewidth',2);
        p.Color(4) = trans(cnt);
        
        sems(cnt,k) = sem;
         
    end
    
    p = plot([1:6],x(1:6),'-','color',cols(cnt,:),'linewidth',3);
    p.Color(4) = trans(cnt);
    cnt = cnt+1;

end

box off
set(gca,'xtick',[1:7],'ylim',[5 30],'fontsize',20,...
'fontweight','bold','xlim',[.8 7.2],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out','xticklabels',{'1' '2' '3' '4' '5' '6' 'GEN'})
xlabel('Block','fontsize',20,'fontweight','bold')
ylabel('False Positive [%]','fontsize',20,'fontweight','bold');
legend(l,{'tVNS-hard' 'tVNS-easy' 'Control'},'location','northeast','linewidth',2,'fontsize',20);
legend boxoff 

%% raw accuracy - all tones

cols = [94 60 153;230 96 8;153 216 201]/255;
trans = [1 1 1 1];

figure;

cnt = 1;

for j=1:3 
    
    x = [];

    for k=1:7
        
        idx = find(vars.block==k & vars.grp==j);
        x(k) = nanmean(vars.pc(idx));
        sem = nanstd(vars.pc(idx))/sqrt(length(idx));
        l(j) = scatter(k,x(k),40,'bo','MarkerFaceColor',cols(j,:),'MarkerEdgeColor',cols(j,:));
        l(j).MarkerFaceAlpha = trans(j);
        l(j).MarkerEdgeAlpha = trans(j);
        hold on;
        p = plot([k k],[x(k)-sem x(k)+sem],'-','color',cols(j,:),'linewidth',2);
        p.Color(4) = trans(j);
        sems(j,k) = sem;
         
    end
    x;
    p = plot([1:6],x(1:6),'-','color',cols(j,:),'linewidth',3);
    p.Color(4) = trans(j);

end

box off
set(gca,'xtick',[1:7],'ylim',[25 75],'fontsize',20,'ytick',[25 50 75],...
'fontweight','bold','xlim',[.8 7],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out','xticklabels',{'1' '2' '3' '4' '5' '6' 'GEN'})
xlabel('Block','fontsize',20,'fontweight','bold')
ylabel('Percent Correct','fontsize',20,'fontweight','bold');
legend(l,{'tVNS-hard' 'tVNS-easy'  'Control'},'location','southeast','linewidth',2,'fontsize',20);
legend boxoff 

%% improved accuracy - all tones

listsub = intersect(vars.sub,vars.sub);
listone = intersect(vars.tone,vars.tone);
vars.pci = [];

for i=1:length(listsub)
    
    for j=1:length(listone)
        
        idx = find(vars.sub==listsub(i) & vars.block==1 & vars.tone==j);
        tmp = vars.pc(idx);
        
        idx = find(vars.sub==listsub(i) & vars.tone==j);
        vars.pci(idx,1) = vars.pc(idx) - tmp;
    
    end
    
end

cols = [94 60 153;230 96 8;153 216 201]/255;
trans = [1 1 1 1];

figure;

cnt = 1;

for j=1:3 
    
    x = [];

    for k=2:7
        
        idx = find(vars.block==k & vars.grp==j);
        x(k) = nanmean(vars.pci(idx));
        sem = nanstd(vars.pci(idx))/sqrt(length(idx));
        l(j) = scatter(k,x(k),40,'bo','MarkerFaceColor',cols(j,:),'MarkerEdgeColor',cols(j,:));
        l(j).MarkerFaceAlpha = trans(j);
        l(j).MarkerEdgeAlpha = trans(j);
        hold on;
        p = plot([k k],[x(k)-sem x(k)+sem],'-','color',cols(j,:),'linewidth',2);
        p.Color(4) = trans(j);
        sems(j,k) = sem;
         
    end
    x;
    p = plot([2:6],x(2:6),'-','color',cols(j,:),'linewidth',3);
    p.Color(4) = trans(j);

end

box off
set(gca,'xtick',[2:7],'fontsize',20,'ytick',[25 50 75],...
'fontweight','bold','xlim',[1.8 7],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out','xticklabels',{'2' '3' '4' '5' '6' 'GEN'})
xlabel('Block','fontsize',20,'fontweight','bold')
ylabel('Percent Improvement','fontsize',20,'fontweight','bold');
legend(l,{'tVNS-hard' 'tVNS-easy'  'Control'},'location','southeast','linewidth',2,'fontsize',15);
legend boxoff 

%% improved accuracy - easier to learn tones

cols = [94 60 153;230 96 8;153 216 201]/255;
trans = [1 1 1 1];

figure;

cnt = 1;

for j=1:3 
    
    x = [];

    for k=2:7
        
        idx = find(vars.block==k & vars.grp==j & (vars.tone==1 | vars.tone==3));
        x(k) = nanmean(vars.pci(idx));
        sem = nanstd(vars.pci(idx))/sqrt(length(idx));
        l(j) = scatter(k,x(k),40,'bo','MarkerFaceColor',cols(j,:),'MarkerEdgeColor',cols(j,:));
        l(j).MarkerFaceAlpha = trans(j);
        l(j).MarkerEdgeAlpha = trans(j);
        hold on;
        p = plot([k k],[x(k)-sem x(k)+sem],'-','color',cols(j,:),'linewidth',2);
        p.Color(4) = trans(j);
        sems(j,k) = sem;
         
    end
    x;
    p = plot([2:6],x(2:6),'-','color',cols(j,:),'linewidth',3);
    p.Color(4) = trans(j);

end

box off
set(gca,'xtick',[2:7],'fontsize',20,'ytick',[25 50 75],...
'fontweight','bold','xlim',[1.8 7],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out','xticklabels',{'2' '3' '4' '5' '6' 'GEN'})
xlabel('Block','fontsize',20,'fontweight','bold')
ylabel('Percent Improvement','fontsize',20,'fontweight','bold');
legend(l,{'tVNS-hard' 'tVNS-easy'  'Control'},'location','southeast','linewidth',2,'fontsize',15);
legend boxoff 

%% improved accuracy - easier to learn tones

cols = [94 60 153;230 96 8;153 216 201]/255;
trans = [1 1 1 1];

figure;

cnt = 1;

for j=1:3 
    
    x = [];

    for k=2:7
        
        idx = find(vars.block==k & vars.grp==j & (vars.tone==2 | vars.tone==4));
        x(k) = nanmean(vars.pci(idx));
        sem = nanstd(vars.pci(idx))/sqrt(length(idx));
        l(j) = scatter(k,x(k),40,'bo','MarkerFaceColor',cols(j,:),'MarkerEdgeColor',cols(j,:));
        l(j).MarkerFaceAlpha = trans(j);
        l(j).MarkerEdgeAlpha = trans(j);
        hold on;
        p = plot([k k],[x(k)-sem x(k)+sem],'-','color',cols(j,:),'linewidth',2);
        p.Color(4) = trans(j);
        sems(j,k) = sem;
         
    end
    x;
    p = plot([2:6],x(2:6),'-','color',cols(j,:),'linewidth',3);
    p.Color(4) = trans(j);

end

box off
set(gca,'xtick',[2:7],'fontsize',20,'ytick',[25 50 75],...
'fontweight','bold','xlim',[1.8 7],'linewidth',2,'fontname','arial');
set(gca,'TickDir','out','xticklabels',{'2' '3' '4' '5' '6' 'GEN'})
xlabel('Block','fontsize',20,'fontweight','bold')
ylabel('Percent Improvement','fontsize',20,'fontweight','bold');
legend(l,{'tVNS-hard' 'tVNS-easy'  'Control'},'location','southeast','linewidth',2,'fontsize',15);
legend boxoff 

