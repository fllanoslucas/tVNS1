

clear all

%% 

vars.sub = [];
vars.block = [];
vars.pr = [];
vars.grp = [];

pathins = {'..\data\tVNS-hard\',...
           '..\data\tVNS-easy\',...
           '..\data\Control\'};
           
for i=1:length(pathins)

    pathin = pathins{i};
    
    tmp = input_retention_correct_trials(pathin);

    vars.sub = [vars.sub;tmp.sub];
    vars.grp = [vars.grp;i*ones(size(tmp.pr))];
    vars.pr = [vars.pr;tmp.pr];
    vars.block = [vars.block;tmp.block];
    
end

vars.pr = 100*vars.pr/40;

idx = find(isnan(vars.pr)==1);
vars.sub(idx) = [];
vars.grp(idx) = [];
vars.block(idx) = [];
vars.pr(idx) = [];

%% plot

cols = [94 60 153;230 96 8;153 216 201]/255;
trans = [1 1 1];

figure;

for j=1:3
    
    x = [];

    for k=1:5
        
        idx = find(vars.block==k+1 & vars.grp==j);
        x(k) = nanmean(vars.pr(idx));
        sem = nanstd(vars.pr(idx))/sqrt(length(idx));
        l(j) = scatter(k,x(k),100,'bo','MarkerFaceColor',cols(j,:),'MarkerEdgeColor',cols(j,:));
        hold on;
        p = plot([k k],[x(k)-sem x(k)+sem],'-','color',cols(j,:),'linewidth',2);
        
    end
    
    p = plot([1:5],x,'-','color',cols(j,:),'linewidth',3);

end

box off
set(gca,'xtick',[1:5],'fontsize',20,'xticklabels',{'2' '3' '4' '5' '6'},...
'fontweight','bold','xlim',[.8 5],'linewidth',2,'fontname','arial','ytick',[10 40 70]);
set(gca,'TickDir','out')
xlabel('Block','fontsize',20,'fontweight','bold')
ylabel('Percent Correct Retained','fontsize',20,'fontweight','bold');
legend(l,{'tVNS-hard' 'tVNS-easy'  'Control'},'location','southeast','linewidth',2,'fontsize',20);
legend boxoff

%% lme

idx1 = find(vars.grp==1); % relevel group
idx3 = find(vars.grp==3);
vars.grp(idx3) = 1;
vars.grp(idx1) = 3;

tab = table(vars.sub,nominal(vars.grp),nominal(vars.block),vars.pr,...
            'VariableNames',{'subject','group','block','pr'});  

mdl = fitlme(tab,'pr ~ group*block + (1|subject)')
