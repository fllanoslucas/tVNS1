

function  [nums] = str_to_number(strs)

    nums = [];

    for i=1:numel(strs)
        
        str = strs{i};
        str = str([1 2 3 5 6]);
        tmp = double(str);
        tmp = [num2str(tmp(1)) num2str(tmp(2)) num2str(tmp(3))...
               num2str(tmp(4)) num2str(tmp(5))];
        nums(i) = str2double(tmp);     
        
    end

end