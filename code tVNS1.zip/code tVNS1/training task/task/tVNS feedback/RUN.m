

clear all hidden
close all
format compact

% double blind randomization

% grps = [];
% 
% for i=1:15
% 
%     grps = [grps randperm(3)];
% 
% end
% 
% save grps grps

% get random id

load grps
slist = dir('data\*.mat');
id = length(slist)+1;
grp = grps(id);

% Pycorder message

prompt = 'Get Pycorder ready and press enter';
x = input(prompt);

% staircase

singleStaircase

prompt = 'Close Pycorder and press enter';
x = input(prompt);

% break

prompt = 'Get Pycorder ready and press enter';
x = input(prompt);

% tone learning

if grp==1

    toneTrainingHard
    
elseif grp==2
    
    toneTrainingEasy
    
else
    
    toneTrainingControl
   
end

