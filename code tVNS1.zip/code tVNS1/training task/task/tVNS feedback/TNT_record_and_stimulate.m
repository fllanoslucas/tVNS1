%% Record and Stimulate
% This script combines stimulation with GSR/PulseOx recording
% via the Shimmer device. 

% TNT_record_and_stimulate(comPort, captureDuration, fileName)

% It is going to be necessary to trigger the
% stimulation using timeStamps, after a certain period of time has passed.
% And then if that has happened, set up the next trial, stimulation, etc....

clear all;
close all;

% add depending on computer
%javaclasspath('/Applications/MATLAB_R2016b.app/java/jar/ShimmerBiophysicalProcessingLibrary_Rev_0_10.jar')
javaclasspath('C:\Program Files\MATLAB\R2016b\java\jar\ShimmerBiophysicalProcessingLibrary_Rev_0_10.jar') % has this been working on all computers?

prompt = {'Enter GSR Comport:','Recording Length(sec):','Enter Filename:', 'Enter Condition List Number', 'Enter 300pw Threshold', 'Enter 500pw Threshold'};
dlg_title = 'Input';
num_lines = 1;
defaultans = {'5','60','test.csv', '1', '1', '1'};
userData = inputdlg(prompt,dlg_title,num_lines,defaultans);

comPort=num2str(cell2mat(userData(1)));
captureDuration=str2num(cell2mat(userData(2)));
fileName=cell2mat(userData(3));
condListNum = str2num(cell2mat(userData(4)));
percept_300_thres = str2double(cell2mat(userData(5)));
percept_500_thres = str2double(cell2mat(userData(6)));

%saveDir='C:\Users\ECoGExpt\Documents\physData\';

%PulseOx channel on Shimmer
PPGChannelNum=12;

%% set up DAQ card

Stim = daq.createSession('ni');
addAnalogOutputChannel(Stim,'Dev4',0,'Voltage');

prompt = 'Press Enter to begin test.';
x = input(prompt);
tic;

% hardcode threshold limits (This is dependent on whether we are using nervana or putty electrode placement
if percept_300_thres > 5
    percept_300_thres = 5;
end

if percept_500_thres > 5
    percept_500_thres = 5;
end


%% Global Parameters
params.sr = 24000; % sampling frequency
params.npulses = 15; % number of pulses in pulse train

%% import trial matrix
% abs_cond_iti is reasonable for recording GSR responses.
% abs_ecog_iti has much faster ITIs, so it may only be appropriate for RR interval and

load(sprintf('abs_cond_iti/abs_cond_iti_%d', condListNum));
trialMatrix = iout;

% add 60 to all the time values to create a baseline period
for i = 1:size(trialMatrix,1)
    trialMatrix{i,3} = trialMatrix{i,3} +60;
end

%% Configure DAQ

% set session rate
Stim.Rate = params.sr;
% set output to 0
outputSingleScan(Stim, 0);

%% definitions
shimmer = ShimmerHandleClass(comPort);                                     % Define shimmer as a ShimmerHandle Class instance with comPort1

fs = 204.8;                                                                % sample rate in [Hz] for PPG
firsttime = true;

% Note: these constants are only relevant to this examplescript and are not used
% by the ShimmerHandle Class
NO_SAMPLES_IN_PLOT = 2000;                                                 % Number of samples that will be displayed in the plot at any one time
DELAY_PERIOD = 0.01;                                                        % A delay period of time in seconds between data read operations
numSamples = 0;

%% PPG filter settings
fclp = 5;                                                                  % corner frequency lowpassfilter [Hz];
nPoles = 2;                                                                % number of poles (HPF, LPF)
pbRipple = 0.5;                                                            % pass band ripple (%)
lpfPPG = FilterClass(FilterClass.LPF,fs,fclp,nPoles,pbRipple);             % lowpass filters for PPG channel

%% PPG2HR settings
numberOfBeatsToAve = 1;                                                    % the number of consecutive heart beats that are averaged to calculate the heart rate. Instantaneous heart rate is calculated after each detected pulse. So the last X instantaneous heart rates are averaged to give the output (where X is numberOfBeatsToAve)) must be >= 1.
useLastEstimate = 1;                                                       % true for repeating last valid estimate when invalid data is detected.
PPG2HR = com.shimmerresearch.biophysicalprocessing.PPGtoHRAlgorithm(fs,numberOfBeatsToAve,useLastEstimate);  % create PPG to Heart Rate object: Sampling Rate = 204.8Hz, Number of Beats to Average = 1 (minimum), Repeat last valid estimate when invalid data is detected.

%% connect and run experiment
if (shimmer.connect)                                                       % TRUE if the shimmer connects

    % Define settings for shimmer
    shimmer.disableallsensors;
    shimmer.setsamplingrate(fs);                                           % Set the shimmer sampling rate
    shimmer.setinternalboard('GSR');                                      % Set the shimmer internal daughter board
    shimmer.setenabledsensors('GSR',1);

    PPGChannel = ['INT A' num2str(PPGChannelNum)];
    shimmer.setenabledsensors(PPGChannel,1);                               % enable PPG Channel
    shimmer.setinternalexppower(1);                                        % set internal expansion power

    if (shimmer.start)                                                     % TRUE if the shimmer starts streaming
        plotData = [];
        timeStamp = [];
        filteredplotData = [];
        heartRate = [];
        GSRData = [];
        storeData = [];
        stimData = [];

        h.figure1=figure('Name','Shimmer signals');     % create a handle to figure for plotting data from shimmer
        set(h.figure1, 'Position', [1300, 80, 800, 900]);

        % create a break button
        stopAcq = uicontrol('Style', 'PushButton', ...
                    'String', 'Break', ...
                    'Callback', 'delete(gcbf)');

        % make the stimulation buffer for the first trial
        curCondition = trialMatrix{1,1};
        curITI = trialMatrix{1,2};
        C = strsplit(curCondition,'_');

        % configure stimulation waveform
        params.pw2 = str2double(C{3}); % pulse width (us)
        params.freq1 = str2double(C{4}); % frequency of stim (Hz)
        params.duration_test = params.npulses/params.freq1; % duration of pulse train (s)

        %disp(params.duration_test)
        amplitude_modifier = str2double(C{2})/10; % amplitude above and below threshold
        if params.pw2 == 300
            params.amp = percept_300_thres + amplitude_modifier; 
        else
            params.amp = percept_500_thres + amplitude_modifier;
        end

        % Generate stimulus waveform
        buf = MakeStimBuffer(params); % hard caps should exist here as well

        % make and load the buffer to the DAQ
        queueOutputData(Stim, buf');
        bufferLoaded = true;
        stimPlayed = true;
        stimEnd=0;

        % Configure timing
        elapsedTime = 0;                                                   % Reset to 0
        trialTime = 0;
        trigTime = 0;
        loadTime = 0;
        cur_trial = 0;
        trial_started = 0;
        stimOnOff = 0;
        totalTime = 0;
        oldTime=0;

        % capture Timers
        captureTimer = tic;                                                               % Start capture timer
        trialTimer = tic;
        triggerTimer = tic;
        loadTimer = tic;

        while (elapsedTime < captureDuration && cur_trial < size(trialMatrix,1) && ishandle(stopAcq))

            % Trial level
            % We want the buffer loaded before the trial starts. If the
            % timer passes the time threshold, then the stimulation is
            % cued, followed by loading the next trial.

            % check if we have moved on to the next trial
            if elapsedTime > trialMatrix{cur_trial+1,3} % if yes:
                cur_trial = cur_trial+1; % update cur_trial
                fprintf('Trial %d initiated at %d\n', cur_trial, round(elapsedTime,2));
                trialTime = toc(trialTimer); %get time when trial begins
                trialMatrix{cur_trial,4} = trialTime; % timestamp the beginning of the trial
                stimPlayed = false; % turn off "stim started" flag
            end

            % if stimulation has already started, we don't want to start it
            % again. Hmm... technically that also includes whether time has
            % passed...

            if stimPlayed == false && bufferLoaded == true
                stimStart = elapsedTime; % get time that stimulation started
                stimEnd = stimStart + params.duration_test; % set time in the future when stim will be off.
                trigTime = toc(triggerTimer); % get time when stimulus is triggered
                trialMatrix{cur_trial,5} = trigTime;
                Stim.startForeground         % stim on, this halts all other operations
                stimOnOff = 1;
                stimPlayed = true;           % flag that stimulation has been on
                bufferLoaded = false;        % flag that the buffer has been played.
            end

            % once the actual waveform has been played, we want to reload the buffer.
            if bufferLoaded == false && stimPlayed == true && cur_trial ~= size(trialMatrix,1)
                % mark that stimulation has ended
                stimOnOff = 0;

                % make the stimulation buffer for the next trial
                curCondition = trialMatrix{cur_trial+1,1};
                curITI = trialMatrix{cur_trial+1,2};
                C = strsplit(curCondition,'_');

                % configure stimulation waveform
                params.pw2 = str2double(C{3}); % pulse width (us)
                params.freq1 = str2double(C{4}); % frequency of stim (Hz)
                params.duration_test = params.npulses/params.freq1; % duration of pulse train (s)

                %disp(params.duration_test)
                amplitude_modifier = str2double(C{2})/10; % amplitude above and below threshold
                if params.pw2 == 300
                    params.amp = percept_300_thres + amplitude_modifier;  
                else
                    params.amp = percept_500_thres + amplitude_modifier;
                end
                % Generate stimulus waveform for the next trial
                buf = MakeStimBuffer(params);
                % make and load the buffer to the DAQ
                queueOutputData(Stim, buf');
                loadTime = toc(loadTimer); % get time when stimulus is triggered
                trialMatrix{cur_trial,6} = loadTime;

                % flag that the buffer has been loaded
                bufferLoaded = true;
            end


            pause(DELAY_PERIOD);     % Pause for this period of time on each iteration to allow data to arrive in the buffer

            [newData,signalNameArray,signalFormatArray,signalUnitArray] = shimmer.getdata('c');   % Read the latest data from shimmer data buffer, signalFormatArray defines the format of the data and signalUnitArray the unit

            % create output file
            if (firsttime==true && isempty(newData)~=1)

                signalNamesString=[char('Time Stamp'), char(','), char('PPG'), char(','), char('PPG Filtered'), char(','), char('Heart Rate'),char(','), char('GSR')]; % create a single string, signalNamesString

                % create a tabbed name for the trial timing info
                tabbedStimOnOff = [char(','), char('stimOnOff'),char(','), char('altTime')];

                % append to the output string
                signalNamesString = strcat(signalNamesString,tabbedStimOnOff);

                % write to file
                dlmwrite(fileName, signalNamesString, '%s');                                % write the signalNamesString as the first row of the file
                firsttime=false; % flag that this is no longer the first time

            end

            % Data read/write level
            if ~isempty(newData)                                           % TRUE if new data has arrived

                % get signal indices
                chIndex(1) = find(ismember(signalNameArray, 'Time Stamp'));
                chIndex(2) = find(ismember(signalNameArray, ['Internal ADC A' num2str(PPGChannelNum)]));   % PPG data output
                chIndex(3) = find(ismember(signalNameArray, 'GSR')); % GSR channel
                PPGData = newData(:,chIndex(2));
                PPGDataFiltered = PPGData;
                PPGDataFiltered = lpfPPG.filterData(PPGDataFiltered);                       % filter with low pass filter
                newheartRate = PPG2HR.ppgToHrConversion(PPGDataFiltered, newData(:,chIndex(1)));                   % compute Heart Rate from PPG data
                newGSRData = newData(:,chIndex(3));


                newStimData(>=trigTime && < ,1)

                plotData = [plotData; PPGData];                                             % update the plotDataBuffer with the new PPG data
                filteredplotData = [filteredplotData; PPGDataFiltered];                     % update the filteredplotData buffer with the new filtered PPG data
                heartRate = [heartRate; newheartRate];                                      % update the filteredHRData buffer with the new filtered Heart Rate data
                GSRData = [GSRData; newGSRData];                                            % update the GSR data
                stimData = [stimData; newStimData];                                         % update the stimulation data

                numPlotSamples = size(plotData,1);
                numSamples = numSamples + size(newData,1);
                timeStampNew = newData(:,chIndex(1));                                       % get timestamps
                timeStamp = [timeStamp; timeStampNew];

                % try a different way of acquiring time, and see how it
                % matches up.
                newTime = elapsedTime;
                altTime = linspace(oldTime,newTime,size(newData,1))';
                oldTime = elapsedTime;

                % use this method to mark onsets and offsets?
                newStimData = repmat(stimOnOff,size(newData,1),1);
                newStimData(altTime >= trigTime & altTime <= stimEnd) = 1;

                % acquire trial timing data
                % this has to be a linear sequence from when the last time
                % stamp was taken (elapsedTime)

                % this seems like it is starting over again and again and
                % again... which matches what I see in the TimeStamp Plot
                storeData = [timeStampNew PPGData PPGDataFiltered newheartRate newGSRData newStimData altTime];
                dlmwrite(fileName, storeData, '-append', 'delimiter', ',', 'precision',16);                % append the new data to the file in a tab delimited format


                % Eliminate elapsed data outside of plot window
                if numSamples > NO_SAMPLES_IN_PLOT

                    plotData = plotData(numPlotSamples-NO_SAMPLES_IN_PLOT+1:end,:);
                    filteredplotData = filteredplotData(numPlotSamples-NO_SAMPLES_IN_PLOT+1:end,:);
                    heartRate = heartRate(numPlotSamples-NO_SAMPLES_IN_PLOT+1:end,:);
                    GSRData = GSRData(numPlotSamples-NO_SAMPLES_IN_PLOT+1:end,:);
                    stimData = stimData(numPlotSamples-NO_SAMPLES_IN_PLOT+1:end,:);
                end
                sampleNumber = max(numSamples-NO_SAMPLES_IN_PLOT+1,1):numSamples;


                % plotting the data
                set(0,'CurrentFigure',h.figure1);
                subplot(5,1,1)
                plot(sampleNumber, plotData(:,1));                         % plot the PPG data
                legend('PPG (mV)');
                xlim([sampleNumber(1) sampleNumber(end)]);
                ylim('auto');

                subplot(5,1,2)
                plot(sampleNumber, filteredplotData(:,1));                 % plot the filtered PPG data
                legend('Filtered PPG (mV)');
                xlim([sampleNumber(1) sampleNumber(end)]);
                ylim('auto');

                subplot(5,1,3)
                plot(sampleNumber, heartRate);                             % plot the Heart Rate data
                legend('Heart Rate (BPM');
                xlim([sampleNumber(1) sampleNumber(end)]);
                ylim('auto');

                subplot(5,1,4)
                plot(sampleNumber, GSRData);                             % plot the Heart Rate data
                legend('GSR');
                xlim([sampleNumber(1) sampleNumber(end)]);
                ylim('auto');

                subplot(5,1,5)
                plot(sampleNumber, stimData);                             % plot the Heart Rate data
                legend('Task Data');
                xlim([sampleNumber(1) sampleNumber(end)]);
                ylim('auto');
            end

            elapsedTime = elapsedTime + toc(captureTimer);                           % Update elapsedTime with the time that elapsed since starting the timer
            captureTimer = tic;                                                       % Start timer

        end
        elapsedTime = elapsedTime + toc(captureTimer);                               % Update elapsedTime with the time that elapsed since starting the timer
        fprintf('The percentage of received packets: %d \n',shimmer.getpercentageofpacketsreceived(timeStamp)); % Detect loss packets
        shimmer.stop;                                                  % Stop data streaming

    end

end

shimmer.disconnect;

clear shimmer;

save(strcat(fileName(1:end-4), '_trialMatrix.mat'),'trialMatrix');
