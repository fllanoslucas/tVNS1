

clear all hidden all
close all
format compact

%% VNS specific setup

  prompt = 'For safety, switch to Voltage mode and remove electrodes whenever stimulation is not being applied. ';
  x = input(prompt);
  
% Creates session to communicate with DAQ

  Stim = daq.createSession('ni');  % requires nidaqmx drivers to have been installed on this computer
  
% Add channel with the handle Stim to the DAQs AO1 port

  addAnalogOutputChannel(Stim,'Dev1',1,'Voltage');  % The second argument of addAnalogOutputChannel (Dev1) needs to be set according to the label assigned to the DAQ card by your system
  params.sr = 24000;  % stim sampling frequency is same as wave frequency

% configure DAQ for stimulation

  Stim.Rate = params.sr;  % set session rate
  outputSingleScan(Stim, 0);  % set output voltage signal to 0, before plugging in electrodes/switching to Current Mode

%% Experiment Setup 

% Get psychtoolbox ready

  warning('off')
  PsychJavaTrouble 
  Screen('Preference', 'SkipSyncTests',1);
  rand('seed',sum(100*clock));
  
  InitializePsychSound(1);
  pahandle = PsychPortAudio('Open',11, 1, 1, 48000,1);  % play from mme [=11]
    
% Read subject number and sensory threshold

  load staircase_output
  sub = subjName;
  outfile = ['data\',sub,'.dat'];
  if exist(outfile) % Prevent overwriting
  error(['The file ' outfile ' already exists.']);
  end
      
% configure stimulation waveform

  params.pw = 300; % pulse width (us)
  params.freq = 25; % frequency of stim (Hz)
  params.npulses = 15; % number of pulses in pulse train
  params.duration_test = params.npulses/params.freq; % duration of pulse train (s)
%   params.amp = percept_thres - 0.2; % set amplitude to 0.2mA under percept threshold
  params.amp = 1 - 0.2; 

% Generate stimulus waveform

  buf = MakeStimBuffer(params); % generate the stimulation waveform

% make and load the buffer to the DAQ

  queueOutputData(Stim, buf'); % loads buffer to the DAQ

% prompt to begin

  prompt = 'You may now plug in the electrodes and switch to Current Mode. Press Enter to begin.';
  x = input(prompt);

% Load data

  expDir = pwd; % set experiment directory
  dataDirectory = [expDir '\data\'];  % data files location
  trainingDirectory = [expDir '\stim\']; % sound files location

% Get the screen size

  sSize = get(0, 'Screensize');
  xSize = sSize(3); % x-dim
  ySize = sSize(4); % y-dim

% Open window if window doesn't exist

  if ~exist('window','var')
  [window, screenRect] = Screen(3,'OpenWindow');  % project to viewpixx (=3)
  HideCursor;
  end

% Define rectangle dimensions

  boxX1 = .85*xSize;
  boxX2 = .95*xSize;
  boxY1 = .10*ySize;
  boxY2 = .20*ySize;
  
% Define center of screen

  rect = sSize;
  Xorigin = (rect(3)-rect(1))/2;
  Yorigin = (rect(4)-rect(2))/2;

% Specify color values

  white = [255 255 255];
  black = [0 0 0];
  backcolor = black;
  textcolor = white;

% Default text size and font type

  textsize = 24;
  Screen(window,'TextFont','Verdana'); % Set text font

% Start things up

  begin_experiment;

  Screen('TextSize', window, 24);
  DrawFormattedText(window, 'In this experiment, you will be asked to categorize sounds into one of four categories', 'center', Yorigin-300, white);
  DrawFormattedText(window, 'You will press either "1", "2", "3" or "4".', 'center', Yorigin-200, white);
  DrawFormattedText(window, 'You will have to make guesses at first,', 'center', Yorigin-100, white);
  DrawFormattedText(window, 'but over time you will begin to learn which sounds go in each category.', 'center', Yorigin, white);
  DrawFormattedText(window, 'After each response, you will be told whether you were correct or incorrect.', 'center', Yorigin+100, white);
  DrawFormattedText(window, 'Please press the spacebar to continue.', 'center', Yorigin+250, white);
  Screen('Flip', window);
  getResp('space');

  trialN = 0;

% List of wavfiles to play

  syl = {'bu', 'di', 'lu', 'ma', 'mi'};                                   
  speak1 = {'a', 'i'};                                                   
  speak2 = {'b', 'h'};                                                  
  iidum1 = 1;                                                            
  iidum2 = 1;

  for i=1:length(syl) % syllables
      
    for j=1:4  % tone cats
        
        for k=1:length(speak1)  % training speakers
            
            wavArray1{iidum1} = [syl{i}, num2str(j), '-', speak1{k}, 'N.wav']; % filenames for training: 2 speakers
            iidum1 = iidum1 + 1;
            
        end
        
        for m=1:length(speak2) % generalization speakers
            
            wavArray2{iidum2} = [syl{i}, num2str(j), '-', speak2{m}, 'N.wav']; % filenames for generalization: 2 speakers
            iidum2 = iidum2+1;
            
        end
        
    end
    
  end
  
%% Training Blocks
  
 for blockN=1:6

     % Randomize the stimuli for this block
     
     randVar = randperm(length(wavArray1));

     % Display inter-block instructions
     
      if blockN~=1
          
        instructions = {'Press the space bar when you are ready to continue.'};
        Screen(window,'DrawText','Press the space bar when you are ready to continue.',Xorigin-300,Yorigin+(textsize+5),textcolor); % fixation cross
        Screen('Flip', window);     
        getResp('space'); % Wait for user to press 'space bar';
        
      end
           
     % Do the actual trials for each block
     
     for i=randVar
        
        trialN = trialN + 1;
        
        Screen(window,'DrawText','+',Xorigin,Yorigin+(textsize+5),textcolor); % fixation cross
        Screen('Flip', window);
        
        wavStr = wavArray1{i};  % get .wav file name
        fileStr = [trainingDirectory '/' wavStr];  % Define full directory call string
        corrResp = wavStr(3);  % correct response number based on file name as a string
        nCR = str2double(corrResp);

        Screen(window,'DrawText', 'Which Category?', Xorigin-100,Yorigin+(textsize+5),textcolor);
        Screen('Flip', window);
        
        [y,Fs] = audioread(fileStr);  % read  .wav file        
        y = resample(y,48000,Fs);  % resample to sound card sampling rate
        PsychPortAudio('FillBuffer', pahandle, y');  % buffer
                
        if wavStr == '1' | wavStr == '3' % stimulation on target tones
            
           Stim.startBackground;  % stim on, this does not halt other operations 
            
           WaitSecs(0.05);  % wait 50 ms before starting the sound file            
           PsychPortAudio('Start', pahandle, 1, 0, 1);  % play sound 
                       
           [Response, RT] = getResp('1!', '2@', '3#', '4$');  % get button response and RT 
           vResp = Response + 1;

           if vResp == nCR  % provide feedback

                corrFeed=['Correct!'];
                Screen(window,'FillRect', [5 5 5],[0 0 15 15]);
                Screen(window,'DrawText',corrFeed,Xorigin-50,Yorigin+(textsize+5),textcolor);
                Screen('Flip', window);
                pause(1);

           else

                incorrFeed = ['Incorrect. '];
                Screen(window,'FillRect', [5 5 5],[0 0 15 15]);
                Screen(window,'DrawText',incorrFeed,Xorigin-50,Yorigin+(textsize+5),textcolor);
                Screen('Flip', window);
                pause(1);

           end 

           Screen(window,'FillRect',backcolor, [0 boxY2 boxX1-5 ySize]);  % clear middle of screen
           Screen(window, 'DrawText','+', Xorigin,Yorigin+(textsize+5),textcolor);
           Screen('Flip', window);  % screen trigger
            
           % WaitSecs(params.duration_test - 0.05); % in case the sound file doesn't end on its own
           Stim.stop(); % stop stimulation session before reload
           queueOutputData(Stim,buf');  % reload buffer to the DAQ
            
        else
                        
           WaitSecs(0.05);  % to be consistent with stimulation trials           
           PsychPortAudio('Start', pahandle, 1, 0, 1);  % play sound 
                       
           [Response, RT] = getResp('1!', '2@', '3#', '4$');  % get button response and RT 
           vResp = Response + 1;

           if vResp == nCR  % provide feedback

                corrFeed=['Correct!'];
                Screen(window,'FillRect', [5 5 5],[0 0 15 15]); 
                Screen(window,'DrawText',corrFeed,Xorigin-50,Yorigin+(textsize+5),textcolor);
                Screen('Flip', window); % screen trigger 
                pause(1);

           else

                incorrFeed = ['Incorrect. '];
                Screen(window,'FillRect', [5 5 5],[0 0 15 15]);  
                Screen(window,'DrawText',incorrFeed,Xorigin-50,Yorigin+(textsize+5),textcolor);
                Screen('Flip', window); % screen trigger
                pause(1);

           end 

           Screen(window,'FillRect',backcolor, [0 boxY2 boxX1-5 ySize]);  % clear middle of screen
           Screen(window, 'DrawText','+', Xorigin,Yorigin+(textsize+5),textcolor);
           Screen('Flip', window);          
            
        end
        
        tic
        
        data{trialN,1} = blockN;
        data{trialN,2} = trialN;
        data{trialN,3} = [wavStr];
        data{trialN,4} = wavStr(1:2);  % Put syllable into data array
        data{trialN,5} = wavStr(5);  % Put speaker into data array
        data{trialN,6} = nCR;  % Put correct response into data array
        data{trialN,7} = vResp;  % Put actual response into data file
        data{trialN,8} = RT;  % Response Time
        
        t1=toc;
        
        pause(1-t1);  % Pause 1s for the ITI
        
     end 
    
 end
   
%% Generalization Block 

temp = blockN + 1;
   
for blockN = temp

     % Randomize the stimuli for this block
     
     randVar = randperm(length(wavArray2));

     % Display inter-block instructions
     
     DrawFormattedText(window, 'Now you will not be told whether your responses are correct.', 'center', Yorigin-300, white);
     DrawFormattedText(window, 'Press the space bar when you are ready to start.', 'center', Yorigin-200, white);
     Screen('Flip', window);
     getResp('space');  % Wait for user to press 'space bar';

     % Do the actual trials for each block
     
     for i=randVar
        
        trialN = trialN + 1;
        
        Screen(window,'DrawText','+',Xorigin,Yorigin+(textsize+5),textcolor); % fixation cross
        Screen('Flip', window);
        
        wavStr = wavArray2{i};  % Get .wav file name
        fileStr = [trainingDirectory '/' wavStr];  % Define full directory call string
        corrResp = wavStr(3);  % Define correct response number based on file name as a string
        nCR = str2double(corrResp);

        Screen(window,'DrawText', 'Which Category?', Xorigin-100,Yorigin+(textsize+5),textcolor);
        Screen('Flip', window);
        
        [y,Fs] = audioread(fileStr);  % Read  .wav file        
        y = resample(y,48000,Fs);  % resample to sound card sampling rate
        PsychPortAudio('FillBuffer', pahandle, y');  % buffer
        WaitSecs(0.05); % to make it consistent with training
        PsychPortAudio('Start', pahandle, 1, 0, 1);  % play
    
        [Response, RT] = getResp('1!', '2@', '3#', '4$');
                
        vResp = Response + 1;

        Screen(window,'FillRect',backcolor, [0 boxY2 boxX1-5 ySize]);       % Clear middle of screen
        Screen(window, 'DrawText','+', Xorigin,Yorigin+(textsize+5),textcolor);
        Screen('Flip', window);

        tic
        
        data{trialN,1} = blockN;
        data{trialN,2} = trialN;
        data{trialN,3} = [wavStr];
        data{trialN,4} = wavStr(1:2);                                       % Put syllable into data array
        data{trialN,5} = wavStr(5);                                         % Put speaker into data array
        data{trialN,6} = nCR;                                               % Put correct response into data array
        data{trialN,7} = vResp;                                             % Put actual response into data file
        data{trialN,8} = RT;                                                % Response Time
        
        t1=toc;
        
        pause(1-t1);                                                        % Pause 1s for the ITI
        
     end 

end

%% close things up
   
end_experiment;
filename = [sub,'.mat'];
save([dataDirectory filename],'data');  
PsychPortAudio('Close',pahandle);
ListenChar(0);
ShowCursor;
fid = fopen([outfile],'w');
fclose(fid);
Screen('CloseAll');

