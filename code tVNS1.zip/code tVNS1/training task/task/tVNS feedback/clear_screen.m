global window black

% Clear screen to gray background:
Screen('FillRect', window,black);
Screen('Flip', window);