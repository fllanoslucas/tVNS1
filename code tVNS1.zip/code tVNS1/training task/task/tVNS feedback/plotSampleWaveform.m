function plotSampleWaveform(amp, pw, freq, npulse)


params.sr = 44100; % sampling frequency
%% set local parameters
params.pw2 = pw; % pulse width (us)
params.freq1 = freq; % frequency of stim (Hz)
params.npulses = npulse;
params.duration_test = npulse/params.freq1; % duration of pulse train (s)
params.amp = amp; % input in Vols

buf = MakeStimBuffer(params);


figure;
plot((1:size(buf,2))/params.sr, buf(1,:), 'r');
hold on
xlabel('Time (s)');
ylabel('Voltage');
ylim([-1 1]);
xlim([-2 6]);
plot(get(gca,'xlim'),[0 0],'b');

grid on

end