

close all hidden
clear all
format compact

stats_and_plots
pulse_artifact_removal_demo