

clear all

load('..\data\vars_demo');

fs = 25000;
add = fs*0.02;

figure

%%

subplot(1,2,1)

time = 1000*[1:length(pons-add:pons+plen+add)]/25000;

plot(time,cz(pons-add:pons+plen+add),'r','linewidth',2);
hold on

cz(pons:pons+plen) = NaN;
plot(time,cz(pons-add:pons+plen+add),'b','linewidth',2);

a = cz(pons-add:pons+plen+add);

ochk = cz(pons-add:pons+plen+add);
cchk = fillgaps(ochk,50); % 2 ms

cz(pons-add:pons+plen+add) = cchk;

plot(time,cz(pons-add:pons+plen+add),'g','linewidth',2);

plot(time,a,'b','linewidth',2);

box off
set(gca,'linewidth',2,'fontsize',20,...
'fontweight','bold');
axis tight
box off
set(gca,'linewidth',3,'fontsize',18,...
'fontweight','bold','linewidth',2);
xlabel('Time [ms]','fontsize',20);
ylabel('Mgnitude [uV]','fontsize',20);
set(gca,'TickDir','out');
xlabel('Time [ms]','fontsize',20);
ylabel('Mgnitude [uV]','fontsize',20);
xlim([18 24]);
l=legend('Pulse artifact','EEG','Artifact removal')
l.LineWidth=2
legend boxoff

%%

subplot(1,2,2)

time = 1000*[1:length(pons-add:pons+plen+add)]/25000;

cz(pons:pons+plen) = NaN;
plot(time,cz(pons-add:pons+plen+add),'b','linewidth',2);
hold on;

a = cz(pons-add:pons+plen+add);

ochk = cz(pons-add:pons+plen+add);
cchk = fillgaps(ochk,50); % 2 ms

cz(pons-add:pons+plen+add) = cchk;

plot(time,cz(pons-add:pons+plen+add),'g','linewidth',2);

plot(time,a,'b','linewidth',2);

box off
set(gca,'linewidth',2,'fontsize',20,...
'fontweight','bold');
axis tight
box off
set(gca,'linewidth',3,'fontsize',18,...
'fontweight','bold','linewidth',2);
xlabel('Time [ms]','fontsize',20);
ylabel('Mgnitude [uV]','fontsize',20);
set(gca,'TickDir','out');
xlabel('Time [ms]','fontsize',20);
ylabel('Mgnitude [uV]','fontsize',20);
xlim([18 24]);

set(gcf,'Position',[75.00 198.00 1135.33 420.00])

