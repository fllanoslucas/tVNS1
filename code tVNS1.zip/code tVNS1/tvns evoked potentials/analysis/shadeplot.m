

function pl = shadeplot(x,y,color)

  m = mean(y,1);
  
  pl = plot(x,m,'linewidth',2,'color',color);
  hold on;
  plot(x,m,'o','markersize',2,'markerfacecolor',color,'color',color);
  
  if size(y,1)>1
  me = std(y)/sqrt(size(y,1));
  X = [x,fliplr(x)];
  Y = [m+me,fliplr(m-me)]; 
  fill(X,Y,color,'edgealpha',0,'facealpha',0.3);
  end

end