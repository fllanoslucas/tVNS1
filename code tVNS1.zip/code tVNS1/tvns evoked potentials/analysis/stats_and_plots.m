

clear all

fs = 25000; 

load('..\data\veps');

%% plot mean vagal evoked response 

figure;

times = 1000/fs*linspace(0,size(veps.vep,2),size(veps.vep,2));

p(1) = shadeplot(times,veps.vep,[0 0 1]);
hold on;
p(2) = shadeplot(times,veps.bsl,[1 0 0]);
box off

set(gca,'linewidth',3,'fontsize',18,'xtick',[0:2:times(end)],...
'fontweight','bold','linewidth',2);

xlabel('Time [ms]','fontsize',20);
ylabel('Mgnitude [uV]','fontsize',20);

ylim([-1 2])

set(gca,'TickDir','out');
legend(p,{'Post-pulse','Pre-Pulse'},'linewidth',2);

%% stats peaks

load('..\data\veps');

peaks = [];
bsls = [];

% N1

twin = [0 4]*fs/1000; % first 4 ms  

peak = [];
bsl = [];

for j=1:size(veps.vep,1)

    [tmp idx] = min(veps.vep(j,1:twin(2))); % stronger negative peak
    
    peak(j) = tmp;
    lat = twin(1)+idx;
    bsl(j) = veps.bsl(j,lat); % basline magnitude for the same latency

end

[hs,ps c d] = ttest2(peak,bsl)

peaks(1,:) = peak;

% P1

twin = [4 9]*fs/1000; % next 5 ms   

peak = [];
bsl = [];

for j=1:size(veps.vep,1)

    [tmp idx] = max(veps.vep(j,twin(1):twin(2))); % stronger positive peak
    peak(j) = tmp;
    lat = twin(1)+idx;
    bsl(j) = veps.bsl(j,lat); % basline magnitude for the same latency

end

[hs,ps c d] = ttest2(peak,bsl)

peaks(2,:) = peak;

% N2

twin = [9 12]*fs/1000;  % last 4 ms 

peak = [];
bsl = [];

for j=1:size(veps.vep,1)

    [tmp idx] = min(veps.vep(j,twin(1):twin(2))); % stronger negative peak
    peak(j) = tmp;
    lat = twin(1)+idx;
    bsl(j) = veps.bsl(j,lat);

end

[hs,ps c d] = ttest2(peak,bsl)

peaks(3,:) = peak;
      
%%  group differences in threshold ? peaks ?

pathin = '..\data\';
data = xlsread([pathin,'thresholds.xlsx']); % load thresholds

thres = [];

for i=1:length(veps.sub)
    
    idx = find(data(:,1)==veps.sub(i));
    thres(1,i) = data(idx,2);
    
end

idx1 = find(veps.grp==1); % threshold ?
idx2 = find(veps.grp==2);
[h p] = ttest2(thres(idx1), thres(idx2))

for j=1:3 % peak ?
    
    y = {};
        
    for i=1:2 % groups receiving stimulation
        
        idx = find(veps.grp==i);
        
        y{i} = peaks(j,idx);
                
    end
        
    [h p] = ttest2(y{1},y{2})
    
end

%% correlation between thresholds and learning improvement ?

load('..\data\behav');
lsub = veps.sub;

li = [];

for j=1:3 % peak

    for i=1:length(lsub) % subs

        idx1 = find(behav.sub==lsub(i) & behav.block==1);
        idx6 = find(behav.sub==lsub(i) & behav.block==6);
        
        if isempty(idx6)==1 

            idx6 = find(behav.sub==lsub(i) & behav.block==5);
            li(i) = mean(behav.pc(idx6))-mean(behav.pc(idx1));
        
        else
            
            li(i) = mean(behav.pc(idx6))-mean(behav.pc(idx1));
        
        end
        
    end
    
    [r p] = corr(peaks(j,:)',li')
    
end

%% correlation between thresholds and peak ?

for j=1:3 % peak

    y = thres;
    x = peaks(j,:);
    
    [r pval] = corr(x',y')

end

%% bar plot thresholds

figure;

range = [0 1 2 3];

titles = {'N1';'P1';'N2'};

for j=1:3 % peaks
    
    x = thres;
    y = peaks(j,:);    
    means = [];
    xx = [];  
    
    for i=1:length(range)-1 
        
        idx = find(x>range(i) & x<=range(i+1));
        means(i) = mean(y(idx));
        xx(i) = range(i) + (range(i+1)-range(i))/2;  
        
    end   
    
    subplot(1,3,j);
    
    bar(xx,means);
    box off
    xlim([0 3])
    set(gca,'fontsize',15,'fontname','arial')
    if j==2
    xlabel('tVNS Intensity [mA]');
    elseif j==1
    ylabel('Peak Amplitude [uV]');
    end
    title(titles{j})
end

